
var myemail= window.localStorage.email;//declaring global variable by window object  

$(document).ready(function(){
	
	var url = "http://ubrica.com/mobile/json.php";
        $.getJSON(url,'email='+myemail, function(result) {
            console.log(result);
			$('#noklist').empty();
            $.each(result, function(i, field) {
var nok_id = field.nok_id;
var name = field.name;
var email = field.email;
var fname = field.fname;
var mname = field.mname;
var lname = field.lname;
var dob = field.dob;
var idnum = field.idnum;
var ppnum = field.ppnum;
var gender = field.gender;
var phonenum1 = field.phonenum1;
var phonenum2 = field.phonenum2;
var email1 = field.email1;
var email2 = field.email2;
var countystate = field.countystate;
var subcounty = field.subcounty;
var ward = field.ward;
var streetaddress = field.streetaddress;
var citytown = field.citytown;
var code = field.code;
var pobox = field.pobox; 




            $("#noklist").append("<a  class='w3-bar-item w3-button w3-text-red' style='width:100%' style='text-decoration:none;' href='edit-profile.html?reg_id=" + nok_id + "&name=" + name + "&email=" + email + "&fname=" + fname + "&mname=" + mname + "&lname=" + lname + "&dob=" + dob + "&idnum=" + idnum + "&ppnum=" + ppnum + "&gender=" + gender + "&phonenum1=" + phonenum1 + "&phonenum2=" + phonenum2 + "&email1=" + email1 + "&email2=" + email2 + "&countystate=" + countystate + "&subcounty=" + subcounty + "&ward=" + ward + "&streetaddress=" + streetaddress + "&citytown=" + citytown + "&code=" + code + "&pobox=" + pobox + "'><i class='material-icons w3-margin-right w3-large w3-text-teal'>edit</i>" + name + "</a>");
});
        });
    });