$(document).ready(function(){
    //Login Function
    $("#login").click(function(){

    });

    //signup function
    $("#signup").click(function(){

    });

    //logout function
    $("#logout").click(function(){

    });
});