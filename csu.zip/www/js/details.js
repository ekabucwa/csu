
var myemail= window.localStorage.email;//declaring global variable by window object  

$(document).ready(function(){
	
	var url = "http://ubrica.com/mobile/json2.php";
        $.getJSON(url,'email='+myemail, function(result) {
            console.log(result);
            $.each(result, function(i, field) {
                var reg_id = field.reg_id;
                var reg_date = field.reg_date;
                var fullname = field.fullname;
var email = field.email;
var title = field.title;
var fname = field.fname;
var mname = field.mname;
var lname = field.lname;
var dob = field.dob;
var idnum = field.idnum;
var ppnum = field.ppnum;
var gender = field.gender;
var phonenum1 = field.phonenum1;
var phonenum2 = field.phonenum2;
var email1 = field.email1;
var email2 = field.email2;
var countystate = field.countystate;
var subcounty = field.subcounty;
var ward = field.ward;
var streetaddress = field.streetaddress;
var citytown = field.citytown;
var code = field.code;
var pobox = field.pobox; 
var name = field.name;
localStorage.reg_id=reg_id;
localStorage.reg_date=reg_date;
localStorage.fullname=fullname;
localStorage.email=email;
localStorage.title=title;
localStorage.fname=fname;
localStorage.mname=mname;
localStorage.lname=lname;
localStorage.dob=dob;
localStorage.idnum=idnum;
localStorage.ppnum=ppnum;
localStorage.gender=gender;
localStorage.phonenum1=phonenum1;
localStorage.phonenum2=phonenum2;
localStorage.email1=email1;
localStorage.email2=email2;
localStorage.countystate=countystate;
localStorage.subcounty=subcounty;
localStorage.ward=ward;
localStorage.streetaddress=streetaddress;
localStorage.citytown=citytown;
localStorage.code=code;
localStorage.pobox=pobox; 
localStorage.name=name; 
		
$("#reg_id1").html(localStorage.reg_id);
$("#reg_date1").html(localStorage.reg_date);
$("#fullname1").html(localStorage.fullname);
$("#email1").html(localStorage.email);
$("#fullname2").html(localStorage.fullname);
$("#email").html(localStorage.email);
$("#title1").html(localStorage.title);
$("#fname1").html(localStorage.fname);
$("#mname1").html(localStorage.mname);
$("#lname1").html(localStorage.lname);
$("#dob1").html(localStorage.dob);
$("#idnum1").html(localStorage.idnum);
$("#ppnum1").html(localStorage.ppnum);
$("#gender1").html(localStorage.gender);
$("#phonenum11").html(localStorage.phonenum1);
$("#phonenum21").html(localStorage.phonenum2);
$("#email11").html(localStorage.email1);
$("#email21").html(localStorage.email2);
$("#countystate1").html(localStorage.countystate);
$("#subcounty1").html(localStorage.subcounty);
$("#ward1").html(localStorage.ward);
$("#streetaddress1").html(localStorage.streetaddress);
$("#citytown1").html(localStorage.citytown);
$("#code1").html(localStorage.code);
$("#pobox1").html(localStorage.pobox); 
$("#name1").html(localStorage.name); 



            });
        });
    });